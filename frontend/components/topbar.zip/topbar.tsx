"use client";

import { Bell, Sparkles, User, Search } from "lucide-react";

export default function Topbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md">
      <div className="flex h-16 items-center justify-between px-6">

        {/* LEFT */}
        <div className="flex items-center gap-2">
          <div className="text-2xl font-bold tracking-tight">
            JOVIXA
          </div>
        </div>

        {/* CENTER */}
        <div className="hidden md:flex items-center w-[40%]">
          <div className="flex items-center w-full rounded-xl border bg-gray-100 px-3 py-2">
            <Search className="h-4 w-4 text-gray-500" />

            <input
              type="text"
              placeholder="Search jobs, skills, companies..."
              className="w-full bg-transparent px-2 outline-none text-sm"
            />
          </div>
        </div>

        {/* RIGHT */}
        <div className="flex items-center gap-4">

          {/* Notification */}
          <button className="rounded-xl p-2 hover:bg-gray-100 transition">
            <Bell className="h-5 w-5" />
          </button>

          {/* AI */}
          <button className="flex items-center gap-2 rounded-xl bg-black px-4 py-2 text-white hover:opacity-90 transition">
            <Sparkles className="h-4 w-4" />
            <span className="hidden md:block text-sm">
              AI
            </span>
          </button>

          {/* Profile */}
          <button className="rounded-full border p-2 hover:bg-gray-100 transition">
            <User className="h-5 w-5" />
          </button>

        </div>
      </div>
    </header>
  );
}