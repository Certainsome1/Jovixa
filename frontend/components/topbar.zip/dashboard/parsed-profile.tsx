import { BadgeCheck } from "lucide-react";

const skills = [
  "CATIA V5",
  "NX CAD",
  "Teamcenter",
  "PLM",
  "GD&T",
  "Automotive Design",
];

export default function ParsedProfile() {
  return (
    <div
      className="
        bg-white
        rounded-2xl
        border
        border-zinc-200
        p-6
        shadow-sm
      "
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-xl bg-zinc-100">
          <BadgeCheck className="w-5 h-5" />
        </div>

        <div>
          <h2 className="text-xl font-semibold">
            Parsed Profile
          </h2>

          <p className="text-sm text-zinc-500">
            AI extracted candidate profile
          </p>
        </div>
      </div>

      <div className="space-y-5">
        <div>
          <p className="text-sm text-zinc-500 mb-2">
            Experience
          </p>

          <h3 className="text-lg font-semibold">
            4 Years
          </h3>
        </div>

        <div>
          <p className="text-sm text-zinc-500 mb-3">
            Skills
          </p>

          <div className="flex flex-wrap gap-2">
            {skills.map((skill) => (
              <span
                key={skill}
                className="
                  px-3 py-1
                  rounded-full
                  bg-zinc-100
                  text-sm
                "
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}