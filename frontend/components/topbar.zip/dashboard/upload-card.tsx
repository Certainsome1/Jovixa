import { UploadCloud } from "lucide-react";

export default function UploadCard() {
  return (
    <div
      className="
        bg-white
        rounded-2xl
        border
        border-zinc-200
        p-6
        shadow-sm
      "
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-xl bg-zinc-100">
          <UploadCloud className="w-5 h-5" />
        </div>

        <div>
          <h2 className="text-xl font-semibold">
            Resume Upload
          </h2>

          <p className="text-sm text-zinc-500">
            Upload PDF or DOCX resume
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <input
          type="file"
          className="
            w-full
            border
            border-zinc-300
            rounded-xl
            p-3
            text-sm
          "
        />

        <button
          className="
            w-full
            bg-black
            text-white
            rounded-xl
            py-3
            font-medium
            hover:bg-zinc-800
            transition
          "
        >
          Upload Resume
        </button>
      </div>
    </div>
  );
}