import { Sparkles } from "lucide-react";

const matches = [
  {
    role: "Senior NX Designer",
    company: "Tata Technologies",
    score: "92%",
  },
  {
    role: "PLM Engineer",
    company: "Capgemini",
    score: "88%",
  },
  {
    role: "CAD Automation Engineer",
    company: "LTTS",
    score: "84%",
  },
];

export default function RankedMatches() {
  return (
    <div
      className="
        bg-white
        rounded-2xl
        border
        border-zinc-200
        p-6
        shadow-sm
      "
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-xl bg-zinc-100">
          <Sparkles className="w-5 h-5" />
        </div>

        <div>
          <h2 className="text-xl font-semibold">
            Ranked Matches
          </h2>

          <p className="text-sm text-zinc-500">
            AI ranked engineering jobs
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {matches.map((match) => (
          <div
            key={match.role}
            className="
              border
              border-zinc-200
              rounded-xl
              p-4
            "
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">
                  {match.role}
                </h3>

                <p className="text-sm text-zinc-500 mt-1">
                  {match.company}
                </p>
              </div>

              <div
                className="
                  px-3 py-1
                  rounded-full
                  bg-black
                  text-white
                  text-sm
                  font-medium
                "
              >
                {match.score}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}