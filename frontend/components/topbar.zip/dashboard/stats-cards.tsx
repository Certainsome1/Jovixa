import {
  BriefcaseBusiness,
  BrainCircuit,
  Trophy,
  UserCheck,
} from "lucide-react";

const stats = [
  {
    title: "Skills",
    value: "12",
    icon: BrainCircuit,
  },
  {
    title: "Experience",
    value: "4 Years",
    icon: UserCheck,
  },
  {
    title: "Stored Jobs",
    value: "148",
    icon: BriefcaseBusiness,
  },
  {
    title: "Top Match",
    value: "92%",
    icon: Trophy,
  },
];

export default function StatsCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
      {stats.map((stat) => {
        const Icon = stat.icon;

        return (
          <div
            key={stat.title}
            className="
              bg-white
              rounded-2xl
              border
              border-zinc-200
              p-6
              shadow-sm
            "
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-zinc-500">
                  {stat.title}
                </p>

                <h2 className="text-3xl font-bold mt-2">
                  {stat.value}
                </h2>
              </div>

              <div className="p-3 rounded-xl bg-zinc-100">
                <Icon className="w-5 h-5 text-zinc-700" />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}