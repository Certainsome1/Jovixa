import { BriefcaseBusiness } from "lucide-react";

const jobs = [
  "Senior CAD Engineer",
  "NX Design Engineer",
  "PLM Consultant",
  "Teamcenter Administrator",
];

export default function StoredJobs() {
  return (
    <div
      className="
        bg-white
        rounded-2xl
        border
        border-zinc-200
        p-6
        shadow-sm
      "
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-xl bg-zinc-100">
          <BriefcaseBusiness className="w-5 h-5" />
        </div>

        <div>
          <h2 className="text-xl font-semibold">
            Stored Jobs
          </h2>

          <p className="text-sm text-zinc-500">
            Recently fetched opportunities
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {jobs.map((job) => (
          <div
            key={job}
            className="
              border
              border-zinc-200
              rounded-xl
              px-4 py-3
              text-sm
              font-medium
            "
          >
            {job}
          </div>
        ))}
      </div>
    </div>
  );
}