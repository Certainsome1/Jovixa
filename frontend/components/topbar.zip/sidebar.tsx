"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import {
  LayoutDashboard,
  BriefcaseBusiness,
  Sparkles,
  FileText,
  Settings,
  User,
} from "lucide-react";

const items = [
  {
    title: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Jobs",
    href: "/jobs",
    icon: BriefcaseBusiness,
  },
  {
    title: "AI Match",
    href: "/match",
    icon: Sparkles,
  },
  {
    title: "Resume",
    href: "/resume",
    icon: FileText,
  },
  {
    title: "Profile",
    href: "/profile",
    icon: User,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: Settings,
  },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside
      className="
        hidden md:flex
        w-64 h-screen
        bg-zinc-950
        border-r border-zinc-800
        text-white
        p-4
        sticky top-0
        flex-col
      "
    >
      {/* Branding */}
      <div className="mb-10">
        <h1 className="text-3xl font-bold tracking-tight">
          Jovixa
        </h1>

        <p className="text-sm text-zinc-400 mt-1">
          AI Career Intelligence
        </p>
      </div>

      {/* Navigation */}
      <nav className="space-y-2">
        {items.map((item) => {
          const Icon = item.icon;

          return (
            <Link
              key={item.title}
              href={item.href}
              className={`
                flex items-center gap-3
                px-4 py-3
                rounded-xl
                transition-all duration-200

                ${
                  pathname === item.href
                    ? "bg-white text-black font-medium shadow-sm"
                    : "hover:bg-zinc-800 text-white"
                }
              `}
            >
              <Icon size={20} />

              <span>{item.title}</span>
            </Link>
          );
        })}
      </nav>

      {/* Bottom Section */}
      <div className="mt-auto pt-6 border-t border-zinc-800">
        <div className="rounded-xl bg-zinc-900 p-4">
          <p className="text-sm font-medium">
            Jovixa MVP
          </p>

          <p className="text-xs text-zinc-400 mt-1">
            AI-powered engineering career platform.
          </p>
        </div>
      </div>
    </aside>
  );
}